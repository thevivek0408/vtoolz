public class HelloWorld {
  /**
   * Prints "Hello, World"
   *
   * @param args user inputs - not used
   */
  public static void main(String[] args) {
    System.out.println("Hello, World");
  }
}